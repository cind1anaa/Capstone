<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Collection Schedule History - Ground Zero</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: #f2f5ef;
    }

    .sidebar {
      position: fixed;
      left: -250px;
      top: 0;
      height: 100%;
      width: 250px;
      background-color: #cfe2c3;
      padding: 20px;
      transition: left 0.3s ease;
      z-index: 1050;
    }

    .sidebar.active {
      left: 0;
    }

    .sidebar .logo img {
      height: 50px;
      margin-bottom: 15px;
    }

    .sidebar h4 {
      color: #27692A;
      margin-top: 10px;
    }

    .sidebar ul {
      list-style: none;
      padding: 0;
      margin-top: 20px;
    }

    .sidebar ul li {
      margin: 15px 0;
      font-size: 16px;
    }

    .sidebar ul li i {
      margin-right: 10px;
    }

    .sidebar ul li a {
      color: #000;
      text-decoration: none;
      display: flex;
      align-items: center;
    }

    .sidebar ul li a.active {
      background-color: #27692A;
      color: white;
      border-radius: 8px;
      padding: 8px 10px;
    }

    .sidebar ul li a.active i {
      color: white;
    }

    .logout {
      position: absolute;
      bottom: 10px;
      width: 50%;
      text-align: center;
    }

    .logout a {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 5px 0;
      color: #000;
      text-decoration: none;
      font-weight: bold;
    }

    .logout a:hover {
      background-color: #b4d7a9;
      border-radius: 4px;
    }

    .logout i {
      margin-right: 4px;
    }

    .topbar {
      background-color: #27692A;
      color: #fff;
      padding: 15px 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      position: sticky;
      top: 0;
      z-index: 1040;
    }

    .toggle-btn {
      font-size: 24px;
      cursor: pointer;
      color: #fff;
    }

    .profile-icon {
      font-size: 24px;
    }

    .overlay {
      position: fixed;
      top: 0;
      left: 0;
      height: 100%;
      width: 100%;
      background-color: rgba(0, 0, 0, 0.4);
      z-index: 1000;
      display: none;
    }

    .overlay.active {
      display: block;
    }

    .dashboard-container {
      padding: 30px 15px;
      transition: margin-left 0.3s ease;
    }

    .sidebar.active ~ .dashboard-container {
      margin-left: 250px;
    }

    .tabs {
      display: flex;
      gap: 10px;
      margin-bottom: 20px;
    }

    .tabs button {
      padding: 10px 20px;
      border: none;
      background-color: #cfe2c3;
      color: #27692A;
      font-weight: bold;
      border-radius: 5px;
    }

    .tabs button.active {
      background-color: #27692A;
      color: #fff;
    }

    .table-section {
      background-color: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
    }

    .status-btn {
      border: none;
      padding: 5px 10px;
      border-radius: 5px;
      font-size: 12px;
      font-weight: bold;
    }

    .btn-blue {
      background-color: #2196F3;
      color: white;
    }

    .btn-red {
      background-color: #f44336;
      color: white;
    }
  </style>
</head>
<body>
  <!-- Sidebar -->
  <div class="sidebar" id="sidebar">
    <div class="logo text-center">
      <img src="images/logo.png" alt="Logo" />
      <h4>Ground Zero</h4>
    </div>
    <ul>
      <li><a href="dashboard.html"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
      <li><a href="feed.html"><i class="bi bi-envelope-fill"></i> News Feed</a></li>
      <li><a href="user.html"><i class="bi bi-people-fill"></i> User Management</a></li>
      <li><a href="monitoring.html"><i class="bi bi-recycle"></i> Waste Monitoring</a></li>
      <li><a href="createSched.html"><i class="bi bi-truck"></i> Collection Schedule</a></li>
      <li><a href="announcement.html"><i class="bi bi-megaphone"></i> Announcements</a></li>
      <li><a href="waste.html"><i class="bi bi-bar-chart-fill"></i> Waste Reports</a></li>
      <li><a href="collection.html"><i class="bi bi-trash3-fill"></i> Collection Request</a></li>
    </ul>
    <div class="logout">
      <a href="logout.html"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </div>
  </div>

  <!-- Overlay -->
  <div class="overlay" id="overlay"></div>

  <!-- Topbar -->
  <div class="topbar d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center gap-3">
      <span class="toggle-btn" id="toggleBtn"><i class="bi bi-list"></i></span>
      <h5 class="m-0">Collection Schedule</h5>
    </div>
    <a href="admin.html">
  <i class="bi bi-person-circle profile-icon" style="color: white;"></i>
</a>
  </div>

  <!-- Main Content -->
  <div class="dashboard-container container-fluid" id="dashboardContainer">
    <div class="tabs">
      <a href="createSched.html"><button>Create Schedule</button></a>
      <a href="scheduled.html"><button>Scheduled Collection</button></a>
      <button class="active">History</button>
    </div>

    <div class="table-section">
      <div class="mb-3 d-flex justify-content-between align-items-center">
        <input type="text" class="form-control w-25" placeholder="Search" />
        <span><i class="bi bi-arrow-down-up"></i></span>
      </div>

      <table class="table table-bordered">
        <thead style="background-color: #cfe2c3;">
          <tr>
            <th>ID</th>
            <th>Barangay</th>
            <th>Collection Date</th>
            <th>Truck Details</th>
            <th>Remarks</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>Bagong Pook</td>
            <td>01/06/25</td>
            <td>254 LXMH</td>
            <td>N/A</td>
            <td>Collected</td>
            <td>
              <button class="status-btn btn-blue">EDIT</button>
              <button class="status-btn btn-red">DELETE</button>
            </td>
          </tr>
          <tr>
            <td>2</td>
            <td>Luta Sur</td>
            <td>01/06/25</td>
            <td>193 HSKN</td>
            <td>N/A</td>
            <td>Collected</td>
            <td>
              <button class="status-btn btn-blue">EDIT</button>
              <button class="status-btn btn-red">DELETE</button>
            </td>
          </tr>
          <tr>
            <td>3</td>
            <td>San Pedro I</td>
            <td>01/07/25</td>
            <td>254 LXMH</td>
            <td>N/A</td>
            <td>Collected</td>
            <td>
              <button class="status-btn btn-blue">EDIT</button>
              <button class="status-btn btn-red">DELETE</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <!-- JS for sidebar toggle and dynamic active class -->
  <script>
    const toggleBtn = document.getElementById('toggleBtn');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    const dashboardContainer = document.getElementById('dashboardContainer');

    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('active');
      overlay.classList.toggle('active');
      dashboardContainer.classList.toggle('active');
    });

    overlay.addEventListener('click', () => {
      sidebar.classList.remove('active');
      overlay.classList.remove('active');
      dashboardContainer.classList.remove('active');
    });

    // Highlight active link in sidebar
    const currentPath = window.location.pathname.split("/").pop();
    const sidebarLinks = document.querySelectorAll(".sidebar ul li a");

    sidebarLinks.forEach(link => {
      const linkPath = link.getAttribute("href");

      // Handle Collection Schedule section (shared among multiple pages)
      const schedulePages = ["createSched.html", "scheduled.html", "history.html"];
      if (schedulePages.includes(currentPath) && linkPath === "createSched.html") {
        link.classList.add("active");
      } else if (linkPath === currentPath) {
        link.classList.add("active");
      }
    });
  </script>
</body>
</html>
