<?php
return [
    'smtp_host' => 'smtp.gmail.com',
    'smtp_port' => 587,
    'smtp_username' => 'your-email@gmail.com',
    'smtp_password' => 'your-app-specific-password',
    'from_email' => 'groundzero@malvar.gov.ph',
    'from_name' => 'Ground Zero Admin'
];